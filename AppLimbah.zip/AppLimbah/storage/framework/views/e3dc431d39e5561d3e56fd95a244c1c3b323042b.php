<?php $__env->startSection('container'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between">
                    <h6>Detail Transaksi</h6>
                </div>
                <?php if(session()->has('success')): ?>
                    <?php
                        $p = session('success');
                    ?>
                    <script>
                        swal({
                            title: 'Berhasil!!',
                            text: '<?= $p ?>',

                            icon: 'success',
                        });
                    </script>
                <?php endif; ?>
                <div class="card-body px-0 pt-0 pb-2">
                    <h4 class="text-center"><?php echo e($data->nama_barang); ?></h4>
                    <div class="row" style="padding: 20px">
                        <div class="col-md-12 d-flex justify-content-center text-center">
                            <div class="form-group <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="form-control-label" for="">Foto Barang</label> <br>
                                <img width="100%" height="400px" src="<?php echo e($data->foto); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-grouphas-danger">
                                <label class="form-control-label" for="">Pelanggan</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e($data->user->name); ?>" disabled name="nama_barang">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="form-control-label" for="">Jenis Barang</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e($data->jenis); ?>" disabled name="nama_barang">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="form-control-label" for="">Harga Awal</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value=" Rp. <?php echo e(number_format($data->harga, 0, ',', '.')); ?>" disabled name="nama_barang">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="form-control-label" for="">Harga Deal</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value=" Rp. <?php echo e(number_format($transaksi->harga_deal, 0, ',', '.')); ?>" disabled
                                    name="nama_barang">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="form-control-label" for="">Status Transaksi</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value=" <?php echo e($transaksi->status); ?>" disabled name="status">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="form-control-label" for="">Berat Barang</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value=" <?php echo e($data->berat); ?>" disabled name="nama_barang">
                            </div>
                        </div>
                    </div>
                    <div class="row" style="padding: 25px; ">
                        <p> <?php echo $data->deskripsi_barang; ?></p>
                    </div>



                </div>
                
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <h6 class="text-center mt-4">Data Penjemputan</h6>
                <div class="card-body text-center">
                    <div class="row">
                        <?php if($penjemputan): ?>
                            <div class="col-md-6">
                                <div class="form-group >
                                <label class="form-control-label"
                                    for="">Petugas</label>
                                    <input type="text" class="form-control" value=" <?php echo e($penjemputan->user->name); ?>"
                                        disabled name="nama_barang">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group >
                            <label class="form-control-label"
                                    for="">Status</label>
                                    <input type="text" class="form-control"
                                        value=" <?php echo e($penjemputan->status == 'jalan' ? 'Petugas Sedang Jalan ke Tempat Kamu' : 'Sudah di jemput oleh petugas'); ?>"
                                        disabled name="nama_barang">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group >
                            <label class="form-control-label"
                                    for="">Detail</label>
                                    <textarea class="form-control" disabled> <?php echo e($penjemputan->deskripsi ?? 'Belum ada detail informasi'); ?> </textarea>
                                </div>
                            </div>
                            <div class="col-md-12 d-flex justify-content-center text-center">
                                <div class="form-group <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="form-control-label" for="">Foto Penjemputan</label> <br>
                                    <img width="100%" height="300px"
                                        src="<?php echo e($penjemputan->foto ?? asset('assets/img/not-found.png')); ?>" alt="">
                                </div>
                            </div>
                        <?php else: ?>
                            <p>Tidak Ada Data Penjemputan</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">

        <?php if($transaksi->status == 'Selesai'): ?>
            <div class="col-md-12 d-flex justify-content-center ">
                <h6>Transaksi Sudah Selesai Terimakasi</h6>
            </div>
        <?php else: ?>
            <div class="col-md-12 d-flex justify-content-center ">
                <button class="btn col-md-10 bg-gradient-primary" style="padding: 15px"
                    onclick="selesaiTransaksi(<?php echo e($transaksi->id); ?>)"> Selesaikan Transaksi Ini</button>
            </div>
        <?php endif; ?>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Penawaran</h5>
                    <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="harga_deal" value="">
                    <input type="hidden" id="status" value="<?php echo e($data->status); ?>">
                    <p>Kamu yakin deal dengan harga penawaran ini?</p>
                    <div class="row mt-4 mb-4">
                        <h4 class="text-center"> Deal di Harga :</h4>
                        <h3 class="text-center" style="font-weight: 800" id="harga"></h3>
                    </div>

                    <div class="row d-flex justify-content-center text-center">
                        <p>Kamu mau transaksi dimana?</p>
                        <div class="col-12 d-flex justify-content-center">
                            <div class="form-check mb-3" style="margin-right:15px">
                                <input class="form-check-input" type="radio" name="type" value="ke-lokasi"
                                    id="customRadio1">
                                <label class="custom-control-label" for="customRadio1">Datang Ke Lokasi</label>
                            </div>
                            <div class="form-check" style="margin-left:15px">
                                <input class="form-check-input" type="radio" name="type" value="di-rumah"
                                    id="customRadio2">
                                <label class="custom-control-label" for="customRadio2">Jemput Di rumah</label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group">
                            <label class="form-control-label" for="">Deskripsi (optional)</label>
                            <textarea class="form-control <?php $__errorArgs = ['alamat_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deskripsi" rows="5"
                                id="deskripsi" placeholder="Tambah deskripsi transaksi tambahan"></textarea>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" onclick="prosestransaksi()" class="btn bg-gradient-primary">Proses
                        Transaksi</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function() { // DON'T EDIT BELOW THIS LINE
            var d = document,
                s = d.createElement('script');
            s.src = 'https://skripsifaras.disqus.com/embed.js';
            s.setAttribute('data-timestamp', +new Date());
            (d.head || d.body).appendChild(s);
        })();

        function buatTransaksi(harga) {
            const status = $('#status').val();
            if (status == 'Non-Aktif') {
                swal("Peringatan Postingan Ini Tidak Aktif!!",
                    "Ubah Postingan Ini menjadi aktif untuk bisa lanjut ke transaksi!", "warning");
                return false;
            }
            $('#exampleModal').modal('show');
            const total = toRp(harga);
            $('#harga_deal').val(harga);
            $('#harga').html(total);
        }

        function prosestransaksi() {
            var radioValue = $("input[name='type']:checked").val();
            if (radioValue == undefined) {
                swal("Peringatan!!", "Pilih lokasi transaksi dulu!", "warning");
            }
            const deskripsi = $('#deskripsi').val();
            const csrf = $('meta[name="csrf-token"]').attr('content');
            const postid = $('#post_id').val();
            const harga = $('#harga_deal').val()
            console.log(harga);
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('create.transaksi')); ?>",
                data: {
                    '_token': csrf,
                    'post_id': postid,
                    'harga_deal': harga,
                    'deskripsi': deskripsi,
                    'type': radioValue
                },

                success: function(data) {
                    if (data.success) {
                        $('#exampleModal').modal('hide');
                        if (data.type == 'ke-lokasi') {
                            swal("Transaksi Berhasil Dibuat!",
                                "Segera selesaikan transaksi, dengan datang ke lokasi cv izhar!", "success");
                        } else {
                            swal("Transaksi Berhasil Dibuat!", "Tunggu petugas jalan ke rumah kamu oke!",
                                "success");

                        }
                        setTimeout(function() {
                            window.location.href = "/transaksi";
                        }, 1000);
                    }
                }

            });
        }

        function selesaiTransaksi(trxid) {
            swal({
                title: 'Kamu Yakin Menyelesaikan Transaksi Ini ?',
                text: 'Aksi ini tidak dapat diulang lagi!!!',
                icon: 'warning',
                dangerMode: true,
                buttons: ['Tidak', 'Yakin']

            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result) {
                    const csrf = $('meta[name="csrf-token"]').attr('content');
                    $.ajax({
                        type: 'POST',
                        url: "<?php echo e(route('transaksi.selesai')); ?>",
                        data: {
                            '_token': csrf,
                            'trxid': trxid,
                        },

                        success: function(data) {
                            if (data.success) {
                                $('#exampleModal').modal('hide');
                                swal("Transaksi Selesai!",
                                    "Transaksi sudah selesai, Terimakasi sudah mempercayakan cv izhar!",
                                    "success");
                                setTimeout(function() {
                                    window.location.href = "/transaksi";
                                }, 2000);
                            }
                        }

                    });
                }
            })

        }
    </script>
    <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by
            Disqus.</a></noscript>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/andysuryawan/Documents/tes /AppLimbah/resources/views/dashboard/transaksi/show.blade.php ENDPATH**/ ?>