<footer class="footer">
    <div class="container ">
        <div class="copyright text-center">
            Copyright
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, Built by
            <a href="https://www.creative-tim.com" target="_blank">Angga.</a>
        </div>
    </div>
</footer>
